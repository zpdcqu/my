# webim

#### 项目介绍
采用springboot和layim构建webim，使用websocket作为通讯协议，目前已经能够正常聊天，并没有对好友的操作进行实现，查找和加好友没有实现，有需要的可以自行实现
请自行下载layim!
账号密码1
![输入图片说明](https://images.gitee.com/uploads/images/2018/1020/151434_30b66301_1720407.png "WX20181020-123143.png")

![输入图片说明](https://images.gitee.com/uploads/images/2018/1020/151443_95ce6f53_1720407.png "WX20181020-123305.png")
#### 安装教程

sql自行导入，配置文件更改数据库信息

http://ip:8080/login
登陆入口

 
