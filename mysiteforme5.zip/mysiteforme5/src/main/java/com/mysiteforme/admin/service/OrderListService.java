package com.mysiteforme.admin.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.mysiteforme.admin.entity.OrderList;
import com.baomidou.mybatisplus.service.IService;
/**
 * <p>
 * 订单列表 服务类
 * </p>
 *
 * @author wangl
 * @since 2019-01-08
 */
public interface OrderListService extends IService<OrderList> {



    int selectMaxId();
}
