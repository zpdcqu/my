package com.mysiteforme.admin.util;

public class OrderConstant {
    private static final String ORDER_BASE_ID= "T1";
}
