package com.mysiteforme.admin.service;

import com.mysiteforme.admin.entity.QuartzTaskLog;
import com.baomidou.mybatisplus.service.IService;
/**
 * <p>
 * 任务执行日志 服务类
 * </p>
 *
 * @author wangl
 * @since 2018-01-25
 */
public interface QuartzTaskLogService extends IService<QuartzTaskLog> {

}
